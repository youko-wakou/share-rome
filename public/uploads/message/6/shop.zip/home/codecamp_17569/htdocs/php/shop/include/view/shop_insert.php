<!DOCYTPE html>
<html lang="ja">
<head>
    <meta charset="utf-8">
    <title>商品管理ページ</title>
    <style>
        body{
        background-color:#ffffde;
        }

        header{
            border-bottom:1px solid black;
            background-color:#ff7789;

            
        }
        h1{
            display:inline-block;
            color:#ffd8d8;
        }

        .form-box {
            display:block;
            margin:15px;
        }
        table,th,td{
            border: 1px solid;
        }
        img{
            width:250px;
        }
        .message{
            background-color:#fcd4d4;
        }
    </style>
</head>
<body>
    <div id="insert_wrap">
        <header>
            <h1>CodeSHOP 管理ページ</h1>
            <a href="/php/shop/user.php" style = "color:white;">ユーザー管理ページ</a>
            <a href="/php/shop/log_out.php" style="text-decoration:none; font-weight:bold; color:white;">ログアウト</a>
        </header>
        <div class="message">
<?php
if(count($err_msg) !==0){ ?>
<?php
foreach ($err_msg as $value){ ?>
            <p><?php echo $value ;?></p>
<?php } ?>
<?php } ?>

<?php
if(count($info_data) !==0){ ?>
<?php
foreach ($info_data as $value){ ?>
            <p><?php echo $value ;?></p>
<?php } ?>
<?php } ?>
       </div>
        
        <form method="post" enctype="multipart/form-data">
            <div class="form_box">
                <label for = "name">商品名：</label>
                <input type="text" name="name" id="name">
            </div>
            <div class="form-box">
                <label for="price">値段：</label>
                <input type="text" name="price" id="price">
            </div>
            <div class="form-box">
                <label for="quantity">個数：</label>
                <input type ="text" name="quantity" id="quantity">
            </div>
            <div class="form_box">
                <input type="file" name="file">
            </div>
            
            <div class="form_box">
                <select name="take_out">
                    <option name="take" value="take">公開</option>
                    <option name="out" value="out">非公開</option>
                </select>
            </div>
            <div class="form_box">
                <input type="submit" value="商品を追加する">
            </div>
            <input type="hidden" name="inputNum" value="1">
        </form>   
    </div>
   
    <div id="goods_table">
        <h1>商品情報の一覧・変更</h1>
        
        
        <table>
            <tr>
                <th>商品画像</th>
                <th>商品名</th>
                <th>値段</th>
                <th>在庫個数</th>
                <th>ステータス</th>
                <th>操作</th>
            </tr>
<?php
foreach($goods_control_get as $value){ ?>
            <tr>
                <td>
                    <img src="img/<?php echo htmlspecialchars($value['img'],ENT_QUOTES,'utf-8'); ?>">
                </td>
                <td>
                    <?php echo htmlspecialchars($value['name'],ENT_QUOTES,'utf-8'); ?>
                </td>
                <td>
                    <?php echo htmlspecialchars($value['price'],ENT_QUOTES,'utf-8'); ?>
                </td>
                <td>
                    <form method="post">
                        <div class="form-box">
                            <input type="text" name="stock_change" value="<?php echo htmlspecialchars($value['quantity'],ENT_QUOTES,'utf-8'); ?>">個
                        </div>
                        <input type="submit" value="変更する">
                        <input type="hidden" name = "idNum" value="<?php echo $value['id']; ?>">
                        <input type="hidden" name="inputNum" value="3">
                    </form>
                </td>
                
                <td>
                    <form method="post">
<?php if($value['status'] ==='0'){?>
                        <input type="submit" value="非公開→公開">
<?php }else{ ?>
                        <input type="submit" value ="公開→非公開">
<?php } ?>      
                        <input type="hidden" name="status" value ="<?php echo $value['status']; ?>">
                        <input type="hidden" name = "idNum" value="<?php echo $value['id']; ?>">
                        <input type="hidden" name="inputNum" value="2">
                    </form>
                </td>
                
                <td>
                    <form method="post">
                        <input type="submit" value="削除する">
                        <input type="hidden" name="idNum" value="<?php echo $value['id']; ?>">
                        <input type="hidden" name="inputNum" value="4">
                        <input type="hidden" name = "delete" value="delete">
                    </form>
                </td>
            </tr>
            
<?php } ?>
        </table>
    </div>
</body>
</html>
