<?php 
//66:user_nameをuser_idに変えようとすると配列が取得できなくなる、sqlで入れると問題なし
//↓↓↓SELECT文でuser_nameとidから配列が取得できるかでカートに商品が入っているかわかるように変えた
//65:~
//二次元配列だからin_arrayが使えない
//これでは$user_nameのショッピングカートに同じ名前の商品が入っていなかったときに更新したい
//主キーが商品名になっているが購入せずに顧客がログアウトしなかった場合顧客が重複し同じ商品をかごに入れられなくなる

require_once '../shop/include/conf/const.php';
require_once '../shop/include/model/function.php';
/////////////////////////////////
$goods_control_get = array();
$err_msg= array();
$info_data = array();
$cart_select_item_id = array();
//var_dump($_POST);
$link = '';
$user_name = '';
$user_id = 0;
$request_method = '';
$amount = 0;
$idNum = 0;
$price = 0;
$id_cnt = 0;
$cart_select_item_id = '';
$select_amount = 0;
$select_amount_plus = 0;
$select_amount_total = 0;
$goods_control_get = '';
/////////////////////////////////////
//
//session開始
session_start();

if(isset($_SESSION['user_id'])===TRUE){
    $user_id = $_SESSION['user_id'];
}else{
    header('Location:login_top.php');
    exit;
}

$link = get_db_connect();
//user_idから名前を取得
$user_name = get_user_name($user_id,$link);
//var_dump($user_name);
/*
if(isset($data[0]['user_name'])){
    $user_name = $data[0]['user_name'];
}else{
    header('Location:log_out.php');
}
*/

//ログイン済みのhp表示
$request_method = get_request_method();
if($request_method ==='POST') {
   //user_id取得できない仮の数字
    $amount = 1;
    $date = date('Y-m-d H:i:s');
    $idNum = get_post_data('idNum');
    $price = get_post_data('price');
    //ショッピングカートのid数カウント
    $id_cnt = shopping_cart_id($link);
    /*
    if(isset($idNum)){
        $_SESSION['count']++;
    }else{
        $_SESSION['count'] = 1;
    }
    var_dump($_SESSION['count']);
    //
    $count = $_SESSION['count'];
    $user_id = $_SESSION['user_id'];
    */
    //トランザクション開始
    mysqli_autocommit($link,false);
    //選択した商品と一致すると配列に入るsqlを作成して1つめはinsert2個以降はupdate処理
    //$user_nameとidで配列が取得できるか
    $cart_select_item_id = cart_item_id_select($user_id,$idNum,$link);
    //まだカートに何も入っていなかったら
    if(count($cart_select_item_id)=== 0){
        if(goods_info_insert($link,$user_id,$idNum,$amount,$date)!==TRUE){
            $err_msg[]='カートへ追加できませんでした';
            
        }
        //既に対象商品を購入済だったら
    }else{

        /* */
        $select_amount = amount_select($idNum,$user_id,$link);
        $select_amount_plus = $select_amount +1;
        $select_amount_total = $select_amount_plus *$price;
       
        //カートの数量を+1にアップロードする
        if(amount_change($select_amount_plus,$user_id,$idNum,$link)!==TRUE){
            $err_msg[] = '商品をカートに入れることができません';
        }
        if(update_date_change($date,$idNum,$link)!==TRUE){
            $err_msg[] = '購入情報を更新できません';
        }
        /*
        if(total_create($link,$select_amount_total,$idNum)!==TRUE){
            $err_msg[] ='データを更新できませんでした';
        }else{
            $info_data[] = 'データを更新しました';
        }
        */
    }
    if(count($err_msg) === 0){
        $info_data[] = '商品をカートへ追加しました';
        mysqli_commit($link);
    }else{
        mysqli_rollback($link);
    }
}
$goods_control_get = control_goods_select($link);
//db切断
close_db_connect($link);

include_once '../shop/include/view/shop_goods.php';