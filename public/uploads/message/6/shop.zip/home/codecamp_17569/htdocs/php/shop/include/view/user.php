<!DOCTYPE html>
<html lang="ja">
    <head>
        <meta charset="utf-8">
        <title>ユーザー管理ページ</title>
        <style>
            body{
                background-color:#ffffde;
            }
             header{
                background-color:#ff7789;
            }
            h1{
                color:#ffd8d8;
            }

            table,td,th{
               border:1px dotted pink;
           } 
        </style>
    </head>
    <body>
        <header>
            <h1>CodeShop ユーザー管理</h1>
        </header>
        <div class="link">
            <a href="shop_insert.php">商品管理ページ</a>
            <a href="log_out.php">ログアウト</a>
        </div>
        
        <div class="user_list">
            <h2>ユーザー情報</h2>
            <table>
                <tr>
                    <th>ユーザーID</th>
                    <th>登録日</th>
                </tr>
    <?php 
    foreach($user_list_get as $value){ ?>
                <tr>
                    <td><?php echo htmlspecialchars($value['user_name'],ENT_QUOTES,'utf-8');?></td>
                    <td><?php echo htmlspecialchars($value['created_date'],ENT_QUOTES,'utf-8');?></td>
                </tr>
    <?php } ?>
            </table>
        </div>
    </body>
</html>