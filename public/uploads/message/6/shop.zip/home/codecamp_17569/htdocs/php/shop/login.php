<?php
require_once '../shop/include/conf/const.php';
require_once '../shop/include/model/function.php';
///////////////
$link = '';
$user_name = '';
$passwd = '';
$check_array = '';
////////////////////
//POSTが送られていなければログイントップへ戻る
if(get_request_method() !=='POST'){
    header('Location:login_top.php');
    exit;
}else{
    session_start();
    $user_name = get_post_data('user');
    $passwd = get_post_data('pass');
    //var_dump($passwd);
    //ユーザー名をCOOKIEに保存
    setcookie('user',$user_name,time() + 60 * 60 * 24 * 365);
    //passworｄをCOOKIEに保存
    //setcookie('pass',$passwd,time() + 60 * 30 * 24 * 365);
    //$_SESSION['user_name'] = $user_name;
    
    //db接続
    $link = get_db_connect();
    //入力されたメールアドレスとパスワードから配列を取得する
    $check_array = check_user_id($link,$user_name,$passwd);
    
    close_db_connect($link);
    //var_dump($user_name);
    //var_dump($passwd);
   
    if($user_name === 'admin' && $passwd === 'admin'){
        //echo 'aaaaaaa';
        $_SESSION['user_id'] = $check_array[0]['id'];
         header('Location:shop_insert.php');
        exit;
        
        
    }else{
    //入力された内容からテーブルが取得できたか検証
        if(isset($check_array[0]['id'])){
            //var_dump(aaaaaaa);
            //var_dump($check_array);
            $_SESSION['user_id'] = $check_array[0]['id'];
            //ログイン済みページへ
            header('Location:shop_goods.php');
            exit;
        }else{
            $_SESSION['login_err_flag'] = TRUE;
            header('Location:login_top.php');
            exit;
        }
    }
}
//include_once '../include/view/login_top.php';
