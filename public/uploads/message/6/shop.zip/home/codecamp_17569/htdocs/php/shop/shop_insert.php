<?php
//varcharを超えた時商品が登録できない
//http://ips.nekotype.com/1350/
//get_post_data($key)でelseをつけたい
//ログインページへ移動できない(ログインできない）
//ログインできないからいつもログインページに行く
//const
require_once '../shop/include/conf/const.php';
//model
require_once '../shop/include/model/function.php';
//////////////////////
$goods_control_get = array();
$err_msg = array();
$info_data = array();
$user_id = 0;
$link = '';
$user_name = '';
$request_method = '';
$now_date = '';
$inputNum = 0;
$type = '';
$file = '';
$name = '';
$price = 0;
$quantity = 0;
$take_out = '';
$status = 0;
$file_check = '';
$id_cnt =0;
$file_up = '';
$status_change = 0;
$idNum = 0;
$stock_change = 0;
$delete = '';
/////////////////////

session_start();

if(isset($_SESSION['user_id'])===TRUE){
    $user_id = $_SESSION['user_id'];
}else{
    header('Location:login_top.php');
    exit;
}
//db接続
$link= get_db_connect();
//user_id からユーザー名を取得
$use_name = get_user_name($user_id,$link);
/*
//ユーザー名が取得できたか
if(isset($data[0]['username'])){
    $user_name = $data[0]['user_name'];
}else{
    header('Location:/php/shop/log_out.php');
}
*/

///////ログイン済みのユーザーほむぺーじ
//request_method
$request_method = get_request_method();
//postが送られてきているか
if($request_method ==='POST'){
    $now_date = date('Y-m-d H:i:s');
    //formのinputNum
    $inputNum = get_post_data('inputNum');
    
    //inputNum１
    if($inputNum ==='1'){
        //var_dump($type);
        //商品名
        $name = get_post_data('name');
        //値段
        $price = get_post_data('price');
        //個数
        $quantity = get_post_data('quantity');
        //公開非公開
        $take_out = get_post_data('take_out');
        //
        if(mb_strlen($take_out)>0 ){
            if($take_out === 'take'){
                $status = 1;
            }else{
                $status = 0;
            }
        }else{
            $err_msg[] = 'ステータスが設定されていません';
        }
        //入力値チェック
       if(input_check_Value_box($name)!==TRUE){
           $err_msg[] = '商品名が入力されていません';
       }else if(mb_strlen($name) > 100){
           $err_msg[] = '商品は100文字以上だと登録できません';
       }

       if(input_check_Value_box($price)!==TRUE){
           $err_msg[] = '値段が入力されていません';
       }else if(input_check_shop_price($price)!==TRUE){
            $err_msg[] ='値段は正の数字で入力してください';
       }
       if(input_check_Value_box($quantity)!==TRUE){
           $err_msg[] = '数量が入力されていません';
       }else if(input_check_shop_quantity($quantity)!==TRUE){
           $err_msg[] = '数量は正の数字で入力してください';
           
       }
       if(isset($_FILES['file']['name'])){
            $file = $_FILES['file']['name'];
            //var_dump($file);
            //画像形式チェック
            if(isset($_FILES['file']['tmp_name'])){
                if(mb_strlen($_FILES['file']['tmp_name'])>0){
                    $type = mime_content_type($_FILES['file']['tmp_name']);
                }else{
                    $err_msg[]= 'ファイルが送られていません';
                }
            }else{
                $err_msg[]= 'ファイルが送られていません';
            }
            if($type !== ''){
                //filecheck
                $file_check = file_type_check($type);
            }
            
        }else{
            $err_msg[]= 'ファイルが送られていません';
        }
        //顧客のidを検出する
        //$id_cnt = shopping_id_table($link);

        //ここまでエラーがなかった場合のみ実行
        if(count($err_msg) === 0){
            $file_up = file_upload();
            //ファイルのアップロードが成功した時だけINSERT
            if(count($err_msg) ===0){
                
                
                //shop_stockへINSERT
                //mysqli::real_escape_string 
                if(shop_insert($link,$file,$name,$price,$now_date,$status,$quantity)!==TRUE){
                    
                    //ファイルを消す処理する？
                    $err_msg[] = '商品登録失敗';
                }else{
                    $info_data[] = '商品登録成功';

                
                }
            }
        }

    }
    
    if($inputNum === '2'){
        //var_dump($status_change);
        //tableのstatus
        $status_change = get_post_data('status');
        //商品のid
        $idNum = get_post_data('idNum');
        //トランザクション開始
        mysqli_autocommit($link,false);
        if($status_change === '0'){
            //ステータスを１に変更
            if(change_one($link,$idNum)!==TRUE){
                $err_msg[] = 'ステータスを変更に失敗しました';
            }
        }else{
            //ステータスを０に変更
            if(change_zero($link,$idNum)!==TRUE){
                $err_msg[] = 'ステータス変更に失敗しました';
            }
        }
        if(count($err_msg)===0){
           mysqli_commit($link);
           $info_data[] = 'ステータスを変更しました';
        }else{
            mysqli_rollback($link);
        }
    }
    
    if($inputNum === '3'){
        //tableの在庫変更
        $stock_change =get_post_data('stock_change');
        $idNum = get_post_data('idNum');
        //トランザクション開始
        mysqli_autocommit($link,false);
        //stockに入力されてる文字数が0でなければ
        if(mb_strlen($stock_change)!==0){
            if(quantity_check($stock_change)!==TRUE){
                $err_msg[] = '在庫数には正の整数を入力してください';
            }
        }else{
            //からだった時にエラーが出るようにするとあぷでーと処理に進まない
            $err_msg[] = '在庫数が空です。正の整数を入力してください';
        }
        
        if(count($err_msg) ===0){
            //在庫数を0にする
            if(shop_stock_change($link,$idNum,$stock_change)!==TRUE){
                $err_msg[] = '在庫数の変更ができませんでした';
            }
            if(update_stock_date($now_date,$idNum,$link)!==TRUE){
                $err_msg[] = '情報の更新ができません';
            }
        }
        if(count($err_msg) === 0){
            $info_data[] = '在庫数を'.$stock_change.'へ変更しました';
            mysqli_commit($link);
        }else{
            mysqli_rollback($link);
        }
    }
    
    if($inputNum === '4'){
        $delete = get_post_data('delete');
        $idNum = get_post_data('idNum');
        if(!empty($delete)){
            //選択された行を削除する
            if(deleteSHOPtable($link,$idNum)!==TRUE){
                $err_msg[]= '削除に失敗しました';
            }else{
                $info_data[]= '削除を完了しました';
            }
            
        }
    }
}
$goods_control_get = control_goods_select($link);
close_db_connect($link);
include_once '../shop/include/view/shop_insert.php';