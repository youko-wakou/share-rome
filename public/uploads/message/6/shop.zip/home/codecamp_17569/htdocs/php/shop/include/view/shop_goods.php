<!--ユーザー名の取得ができない-->
<!DOCTYPE html>
<html lang="ja">
    <head>
        <meta charset="utf-8">
        <title>商品一覧</title>
        <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet">
        <style>
             body{
                background-color:#ffffde;
            }
            header{
                background-color:#ff7789;
            }
            .title{
                display:inline-block;
                color:#ffd8d8;
            
            }
            .goods{
                width:300px;
            }
            .form-box input {
                background-color: pink;
            }
            .form-box{
                text-align:center;
            }
            div.goods{
                padding:15px;
                display:inline-block;
            }
            .goods span {
                display:block;
                text-align:center;
            }
            .message{
                background-color:pink;
            }
            
        </style>
    </head>
    <body>
        <div class="wrap">
            <header>
                <h1 class="title">CodeCampSHOP</h1>
                <span style = "color:white;">ユーザー名：<?php echo htmlspecialchars($user_name,ENT_QUOTES,'utf-8');?></span>
                <a href="shopping_cart.php"><span class="fa fa-shopping-cart fa-4x" style="color:white;"></span></a>
                <a href="log_out.php" style="text-decoration:none; font-weight:bold; color:white;">ログアウト</a>
            </header>
            
            <div class="goods_list">
                <div class="message">
<?php
if(count($err_msg)>0){?>
<?php 
foreach($err_msg as $value){ ?>
                <p><?php echo htmlspecialchars($value,ENT_QUOTES,'utf-8');?></p>
<?php } ?>
<?php } ?>

<?php
if(count($info_data)>0){?>
<?php 
foreach($info_data as $value){ ?>
                <p><?php echo htmlspecialchars($value,ENT_QUOTES,'utf-8');?></p>
<?php } ?>
<?php } ?>

                </div>
    <?php 
    foreach($goods_control_get as $value){ ?>
    <?php
    if($value['status']!== '0'){ ?>
                <div class="goods">
                    <form method="post">    
                        <span>
                            <img src="img/<?php echo htmlspecialchars($value['img'],ENT_QUOTES,'utf-8');?>">
                        </span>
                        <span>
                            <?php echo htmlspecialchars($value['name'],ENT_QUOTES,'utf-8'); ?>
                        </span>
                        <span>
                            <?php echo htmlspecialchars($value['price'],ENT_QUOTES,'utf-8'); ?>
                        </span>
    <?php if($value['quantity'] !=='0') { ?>
                        <div class="form-box">
                            <input type="submit" value="購入する">
                        </div>
    <?php }else{ ?>
                        <div class="form-box">
                            <p style="color:red; text-align:center;">売り切れ</p>
                        </div>
    <?php } ?>
    
                        <input type="hidden" name="idNum" value="<?php echo $value['id']; ?>">
                        <input type="hidden" name="name" value="<?php echo $value['name'];?>">
                        <input type = "hidden" name ="price" value="<?php echo $value['price'];?>">
                    </form>
                </div>
    <?php } ?>
    <?php } ?>
                    
                
            </div>
        </div>
    </body>
</html>