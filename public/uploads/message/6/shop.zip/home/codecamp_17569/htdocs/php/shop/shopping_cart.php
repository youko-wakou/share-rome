<?php
//76:85:$user_nameを$user_idに変えようとすると合計金額が出なくなる、sqlで入れると配列は取得できる
//$_SESSIONでuser_nameが取得できない
//84~ :配列で在庫戸数をupdateできないかやってみたけどできなかった
//UPDATE shop_stock SET amount = [配列,配列]　WHERE id = [配列,配列];

require_once '../shop/include/conf/const.php';
require_once '../shop/include/model/function.php';

////////////////////////
$get_cart_table = array();
$answer= array();
$err_msg= array();
$info_data =array();
$get_array_id = array();
$get_array_amount = array();
$get_goods_name_update = array();
//var_dump($_POST);
$date = date('Y-m-d H:i:s');
//$_SESSIONでuser_nameが取得できない
$link = '';
$user_id = '';
$user_name = '';
$request_method = '';
$inputNum = 0;
$item_id= 0;
$delete = '';
$change_amount = 0;
$price = 0;
$answers = '';
$sum_answer = 0;
$get_cart_table = '';
$get_array_id = '';
$get_cart_table = '';
$answer = '';
$sum_answer = 0;
//////////////////////////
session_start();

if(isset($_SESSION['user_id'])===TRUE){
    $user_id = $_SESSION['user_id'];
}else{
    header('Location:login_top.php');
    exit;
}
$link = get_db_connect();
$user_name = get_user_name($user_id,$link);
$request_method = get_request_method();
if($request_method === 'POST'){
    
$inputNum = get_post_data('inputNum');

    //商品削除の時のform
    if($inputNum === '1'){
        $item_id = get_post_data('item_id');
        
        $deleate = get_post_data('deleate');
        if($deleate === 'deleate'){
           if(deleate_goods_shop($link,$user_id,$item_id)!==TRUE){
               $err_msg[] = 'カートから商品を削除できません';
           }else{
               $info_data[] = 'カートから削除しました';
           }
        }
    }
    //数量変更（UPLOAD）のform
    if($inputNum === "2"){
        $change_amount = get_post_data('change_amount');
        $item_id = get_post_data('item_id');
        //var_dump($item_id);
        $price = get_post_data('price');
        
        //トランザクション開始
        //mysqli_autocommit($link,false);

        //入力値チェック
        if(number_check($change_amount)!==TRUE){
            $err_msg[]= '商品数の変更は正の整数のみ入力可能';
        }
        //エラーが０だった時に数量変更のUPLOAD
        if(count($err_msg)===0){
            if(update_amount($link,$change_amount,$date,$user_id,$item_id)!==TRUE){
                $err_msg[] = '数量を変更できません';
            }else{
                $info_data[] = '数量を'.$change_amount.'へ変更しました';    
            }
        }
        /*
        if(count($err_msg) ===0){
            $info_data[] = '数量を'.$change_amount.'へ変更しました';
            mysqli_commit($link);
        }else{
            mysqli_rollback($link);
        }
        */
    }
    
    if($inputNum === '3'){
        //配列にpriceとamountの掛け算の答えを算出して配列に入れて
        $answers = cart_select_answer($link,$user_id);
        //配列に入れたものをarray_sumで合計値を取り出す
        $sum_answer = array_sum($answers);
        

        if($sum_answer === 0){
            $err_msg[] = '購入商品がありません';
        }
        $get_cart_table = cart_select($link,$user_id);
        //var_dump($get_cart_table);
        /**/
        
        if(count($err_msg) === 0 ){
            //トランザクション開始
            mysqli_autocommit($link,false);

            //ショッピングカートのテーブルからidと在庫から購入した数を引いたamount配列でupdateしたい
            //アイテムのid
            $get_array_id =  get_update_item_id($link,$user_id);
            //在庫から購入数を引いた数
            //$get_array_amount = get_update_quantity($link);
            //二つの配列をまとめて更新したいfunction25行目
            //var_dump($get_array_id);
            //var_dump($get_array_amount);

            if(update_quantity_amount($link,$get_array_id)!==TRUE){
                $err_msg = '購入手続きに失敗しました';
            }
            if(delete_cart_shop($link,$user_id)!==TRUE){
                $err_msg[] = '購入に失敗しました';
            }
            //update
            //var_dump($get_goods_name_up);
            if(update_goods_datetime($link,$get_array_id,$date)!==TRUE){
                $err_msg[] = '情報を更新できませんでした';
            }
             /**/
            //トランザクション判定
            if(count($err_msg)=== 0){
                $info_data[] = '購入処理完了';
                mysqli_commit($link);
            }else{
                mysqli_rollback($link);
            }
       
        }
       

        include_once '../shop/include/view/shopping_result.php';
        exit;
        
    }
     
}

$get_cart_table = cart_select($link,$user_id);
//配列にpriceとamountの掛け算の答えを算出して配列に入れて
$answer = cart_select_answer($link,$user_id);
//var_dump(array_sum($answer));
//配列に入れたものをarray_sumで合計値を取り出す
$sum_answer = array_sum($answer);
//db切断
close_db_connect($link);

include_once '../shop/include/view/shopping_cart.php';