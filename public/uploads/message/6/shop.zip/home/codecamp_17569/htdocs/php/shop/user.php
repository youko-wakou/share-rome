<?php
require_once '../shop/include/conf/const.php';
require_once '../shop/include/model/function.php';
///////////////////////////////////
$user_list_get = array();
$link = '';
$user_list_get = '';
/////////////////////////////////

session_start();
if(isset($_SESSION['user_id'])=== TRUE){
    $user_id = $_SESSION['user_id'];
}else{
    header('Location:login_top.php');
    exit;
}
$link = get_db_connect();
$user_list_get = user_table($link);
include_once '../shop/include/view/user.php';