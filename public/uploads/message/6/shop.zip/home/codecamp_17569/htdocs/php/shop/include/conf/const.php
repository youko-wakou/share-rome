<?php
define('DB_HOST',   'localhost'); // データベースのホスト名又はIPアドレス
define('DB_USER',   'codecamp17569');  // MySQLのユーザ名
define('DB_PASSWD', 'DBBTFVMF');    // MySQLのパスワード
define('DB_NAME',   'codecamp17569');    // データベース名
  
define('HTML_CHARACTER_SET', 'UTF-8');  // HTML文字エンコーディング
define('DB_CHARACTER_SET',   'UTF8');   // DB文字エンコーディング