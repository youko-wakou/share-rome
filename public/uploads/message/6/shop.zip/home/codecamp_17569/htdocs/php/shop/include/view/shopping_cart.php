<!DOCTYPE html>
<html lang="ja">
    <head>
        <meta charset="utf-8">
        <title>ショッピングカート</title>
        <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet">
        <style>
            body{
                background-color:#ffffde;
            }
            header{
                background-color:#ff7789;
            }
            h1{
                display:inline-block;
                color:#ffd8d8;
            }
            img{
                width:150px;
            }
            form{
                display:inline-block;
            }
            ul,li{
                list-style:none;
            }
            .goods{
                background-color:#ffd8d8;
                padding:15px;
                border-bottom:1px dotted #ff7789;
            }
            input.bought {
                background-color:#ff9191;
                width:250px;
                height:50px;
                border:none;
                border-radius:70px;
                color:white;
                font-weight:bold;
                font-size:25px;
                cursor:pointer;
            }
            
            
        </style>
        
    </head>
    <body>
        <div id="warap">
            <header>
                <a href="shop_goods.php"><h1>CodeCampSHOP</h1></a>
                <span style = "color:white;">ユーザー名：<?php echo htmlspecialchars($user_name,ENT_QUOTES,'utf-8');?></span>
                <a href="shopping_cart.php"><span style="color:white;" class="fa fa-shopping-cart fa-4x"></span></a>
                <a href="log_out.php" style="text-decoration:none; font-weight:bold; color:white;">ログアウト</a>
            </header>
            
            <div class="message">
    <?php
    if(count($err_msg)>0){ ?>
    <?php 
    foreach($err_msg as $value){ ?>
                <p><?php echo $value; ?></p>
    <?php } ?>
    <?php } ?>
    
    
    <?php
    if(count($info_data)>0){ ?>
    <?php 
    foreach($info_data as $value){ ?>
                <p><?php echo $value; ?></p>
    <?php } ?>
    <?php } ?>

            </div>
            
            <div id="cart">
                <h2 style="color:#ff7789;"><?php echo $user_name; ?><span style = "font-size:10px;">さんのショッピングカート<span></h2>
                
                <ul>
    <?php
    foreach($get_cart_table as $value){ ?>
                    <li>
                        
                        <div class="goods">
                           
                             <img src="img/<?php echo htmlspecialchars($value['img'],ENT_QUOTES,'utf-8');?>">
                             <span><?php echo htmlspecialchars($value['name'],ENT_QUOTES,'utf-8');?></span>
                              <form method="post">
                                 <input type="submit" value="削除">
                                 <input type="hidden" name="deleate" value="deleate">
                                 <input type="hidden" name = "item_id" value="<?php echo $value['item_id'] ;?>">
                                 <input type="hidden" name="inputNum" value="1">
                              </form>
                             <span><?php echo htmlspecialchars($value['price'],ENT_QUOTES,'utf-8');?>円</span>
                             <form method="post">
                                <input type="text" name="change_amount" value="<?php echo $value['amount'];?>">
                                <input type="submit" value="変更">
                                <input type="hidden" name = "item_id" value="<?php echo $value['item_id'] ;?>">
                                <input type = "hidden" name = "price" value="<?php echo $value['price']; ?>">
                                <input type="hidden" name="inputNum" value="2">
                             </form>
                        </div>
                        
                    </li>
    <?php } ?>
                </ul>
                <div class="result">
                    <p style="display:inline-block;">合計金額：</p>
                    <span><?php echo htmlspecialchars($sum_answer,ENT_QUOTES,'utf-8');?>円</span>
                </div>

                <div class="button_box">
                    <form method="post">
                        <input class="bought" type="submit" value="購入する">
                        <input type="hidden" name="inputNum" value="3">
                    </form>
                </div>
                
            </div>
        </div>
    </body>
</html>