<?php
//↓↓↓user_nameで$sqlで検索して配列に値が入っているかで値が取得できるか否かで判定できた
//33:同じ名前のユーザーがいた時ユーザーネーム配列と一致した時はじきたい
//二次元配列でin_arrayが使えない、すでに登録されているuser_nameの登録方法

//http://qiita.com/asayamakk/items/1cfae1c775d7e4d64755
require_once '../shop/include/conf/const.php';
//model
require_once '../shop/include/model/function.php';
////////////////
$err_msg = array();
$info_data = array();
$user_name_select= array();
$user_name_value = array();
//var_dump($_POST);
$link = '';
$user_name = '';
$passwd = '';
$user_name_value = '';
$id_cnt = 0;

///////////////////
//コネクトに接続
$link = get_db_connect();
//POST取得

$request_method = get_request_method();
if($request_method === 'POST'){
    //user_name配列取得
   //$user_name_select = user_name_search($link);

    $date = date('Y-m-d H:i:s');
   $user_name = get_post_data('user');
   $passwd = get_post_data('pass');
   //入力されていないものがあるか
   if(empty_check_user($user_name)!==TRUE){
       $err_msg[] = 'ユーザー名が入力されていません';
   }else if(Character_check_user_name($user_name)!==TRUE){
      $err_msg[]='「ユーザ名」は、「使用可能文字は半角英数字」かつ「文字数は6文字以上」のみを可能とする'; 
   }
   //文字制限チェック
   if(empty_check_pass($passwd)!==TRUE){
       $err_msg[] = 'パスワードが入力されていません';
   }else if(Charcter_check_passwd($passwd)!==TRUE){
       $err_msg[] = '「パスワード」は、「使用可能文字は半角英数字」かつ「文字数は6文字以上」のみを可能とする。';
   }
   //user_nameの入った配列
   //in_array使用できない
   //配列が取得できるか
   $user_name_value = user_name_get($link,$user_name);
   if(count($user_name_value) >0){
       $err_msg[] = '既に使われている名前が入力されました';
   }
   
   /*
   foreach($user_name_select as $data){
       if($data ===  $user_name){
          $err_msg[] =  '既に同じ名前が使用されています';
       }
   }*/
   /*
   $user_check = array_search($user_name,array_column($user_name_select,'user_name'));
       if($user_check === $user_name){
           $err_msg[] = '既に使用されている名前です';
       }
   */
   //var_dump($user_name);
   //var_dump(in_array($user_name,$user_name_select));

   if(count($err_msg)===0){
       //id数をテーブルからカウントする
       //$id_cnt = count_id($link);
       //登録した情報をinsertする
       if(sign_up_insert($link,$passwd,$user_name,$date)!==TRUE){
           $err_msg[]= 'ユーザー登録できません';
       }else{
           $info_data[] = 'ユーザー登録が完了しました';
       }
   }
   /*
   //SESSION
   if(count($err_msg) === 0){
       header('Location:shop_goods.php');
       exit;
   }
   */
}

//view
include_once '../shop/include/view/sign_up.php';
