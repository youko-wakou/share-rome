<?php
/**
* insertを実行する
*
* @param obj $link DBハンドル
* @param str SQL文
* @return bool
*/
function insert_db($link, $sql) {
   // クエリを実行する
   if (mysqli_query($link, $sql) === TRUE) {
       return TRUE;
   } else {
       return FALSE;
   }
}
/**
* 新規商品を追加する
*
* @param obj $link DBハンドル
* @param str $goods_name 商品名
* @param int $price 価格
* @return bool
*/
function update_quantity_amount($link,$get_array_id){
    foreach($get_array_id as $value){
        $sql = 'UPDATE shop_stock SET quantity = \''.$value['answer'].'\' WHERE id = \''.$value['item_id'].'\'';
        //var_dump($sql);
        if(insert_db($link,$sql)===FALSE){
            return false;
        }

    }
    return true;
}
function update_goods_datetime($link,$get_array_id,$date){
    foreach($get_array_id as $value){
        $sql = 'UPDATE shop_stock SET updated_date = \''.$date.'\' WHERE id = \''.$value['item_id'].'\'';
        //var_dump($sql);
        if(insert_db($link,$sql) === FALSE){
            return false;
        }
    }
    return true;
}

function goods_info_insert($link,$user_id,$idNum,$amount,$date){
    $data = array(
        //'id' => $id_cnt,
        'user_id' => $user_id,
        'item_id'=> $idNum,
        'amount' => $amount,
        'update_data' => $date,
        'created_date' => $date
    );
    $sql = 'INSERT INTO shopping_cart(user_id,item_id,amount,update_data,created_date) VALUES(\''.implode('\',\'',$data).'\')';
    //var_dump($sql);
    return insert_db($link,$sql);

}
function amount_change($select_amount_plus,$user_id,$idNum,$link){
    $sql = 'UPDATE shopping_cart SET amount = \''.$select_amount_plus.'\' WHERE item_id = \''.$idNum.'\' AND user_id = \''.$user_id.'\'';
    return insert_db($link,$sql);
}
function total_create($link,$select_amount_total,$idNum){
    $sql = 'UPDATE shopping_cart SET total = \''.$select_amount_total.'\'WHERE item_id = \''.$idNum.'\'';
    return insert_db($link,$sql);
}
function update_stock_date($now_date,$idNum,$link){
    $sql = 'UPDATE shop_stock SET updated_date = \''.$now_date.'\' WHERE id = \''.$idNum.'\'';
    return insert_db($link,$sql);
}

function update_date_change($date,$idNum,$link){
    $sql = 'UPDATE shopping_cart SET update_data = \''.$date.'\' WHERE item_id = \''.$idNum.'\'';
    return insert_db($link,$sql);
}
function deleate_goods_shop($link,$user_id,$item_id){
    $sql = 'DELETE FROM shopping_cart WHERE item_id = \''.$item_id.'\' AND user_id =\''.$user_id.'\'';
    return insert_db($link,$sql);
}
function update_amount($link,$change_amount,$date,$user_id,$item_id){
    $sql = 'UPDATE shopping_cart SET amount = \''.$change_amount.'\' , update_data = \''.$date.'\' WHERE user_id = \''.$user_id.'\' AND item_id = \''.$item_id.'\'';
    return insert_db($link,$sql);
}
function delete_cart_shop($link,$user_id){
    $sql = 'DELETE FROM shopping_cart WHERE user_id = \''.$user_id.'\'';
    return insert_db($link,$sql);
}

/**
* リクエストメソッドを取得
* @return str GET/POST/PUTなど
*/
function get_request_method() {
   return $_SERVER['REQUEST_METHOD'];
}
/**
* POSTデータを取得
* @param str $key 配列キー
* @return str POST値
*/
function get_post_data($key) {
   $str = '';
   if (isset($_POST[$key]) === TRUE) {
       $str = $_POST[$key];
   }
   return $str;
}

/*db接続
@return obj $link DB接続
*/
function get_db_connect(){
    if(!$link = mysqli_connect(DB_HOST,DB_USER,DB_PASSWD,DB_NAME)){
        die('error:'.mysqli_connect_error());
    }
    mysqli_set_charset($link,DB_CHARACTER_SET);
    return $link;
}
/*
テーブル取得
@param obj $link
@return array $get_array
*/

//shop_stock
function control_goods_select($link){
    $sql = 'SELECT id,img,quantity,name,price,status FROM shop_stock';
    return get_array($link,$sql);
}

///////////////////////////////////////
function check_user_id($link,$user_name,$passwd){
    $sql = 'SELECT id FROM sign_up_user WHERE user_name = \''.$user_name.'\' AND password = \''.$passwd.'\''; 
    return get_array($link,$sql);
}
function user_table($link){
    $sql ='SELECT user_name,created_date FROM sign_up_user';
    return get_array($link,$sql); 
}
function cart_select($link,$user_id){
    $sql = 'SELECT shop_stock.id,shop_stock.img,shop_stock.name,shop_stock.price,shopping_cart.item_id,shopping_cart.amount, shop_stock.price*shopping_cart.amount AS answer FROM shop_stock LEFT JOIN shopping_cart ON shopping_cart.item_id = shop_stock.id WHERE user_id = \''.$user_id.'\'';
    return get_array($link,$sql);
}
function cart_item_id_select($user_id,$idNum,$link){
    $sql = 'SELECT item_id,user_id FROM shopping_cart WHERE item_id =\''.$idNum.'\' AND user_id = \''.$user_id.'\'';
    return get_array($link,$sql);
}

function cart_select_answer($link,$user_id){
    $sql = 'SELECT shop_stock.id,shop_stock.img,shop_stock.name,shop_stock.price,shopping_cart.item_id,shopping_cart.amount, shop_stock.price*shopping_cart.amount AS answer FROM shop_stock LEFT JOIN shopping_cart ON shopping_cart.item_id = shop_stock.id WHERE user_id = \''.$user_id.'\'';
    return get_array_answer($link,$sql);
}
function user_name_get($link,$user_name){
    $sql = 'SELECT user_name FROM sign_up_user WHERE user_name = \''.$user_name.'\'';
    return get_array($link,$sql);
}

function get_array_answer($link,$sql){
    $data = array();
    if($result = mysqli_query($link,$sql)){
        if(mysqli_num_rows($result) >0){
            while($row  = mysqli_fetch_assoc($result)){
                $data[] = $row['answer'];
            }
        }
        mysqli_free_result($result);
    }
    return $data;
}
function get_update_item_id($link,$user_id){
    $sql = 'SELECT shopping_cart.item_id,shop_stock.name,shop_stock.quantity - shopping_cart.amount AS answer,quantity,amount FROM shop_stock INNER JOIN shopping_cart ON shopping_cart.item_id = shop_stock.id WHERE user_id = \''.$user_id.'\'';
    //var_dump($sql);
    return get_array($link,$sql);
}
function get_update_quantity($link){
    $sql = 'SELECT shopping_cart.item_id,shop_stock.quantity - shopping_cart.amount AS answer FROM shop_stock LEFT JOIN shopping_cart ON shopping_cart.item_id = shop_stock.id';
    return get_array_quantity($link,$sql);
}

function get_array_quantity($link,$sql){
    $data = array();
    if($result = mysqli_query($link,$sql)){
        if(mysqli_num_rows($result) >0){
            while($row  = mysqli_fetch_assoc($result)){
                $data[] = $row['answer'];
            }
        }
        mysqli_free_result($result);
    }
    return $data;

}
function get_user_name($user_id,$link){
    $sql ='SELECT user_name FROM sign_up_user WHERE id = ' .$user_id;
    $data =  get_array($link,$sql);
    return $data[0]['user_name'];
}

/*
テーブルを配列に入れて表示する
@param obj $link
@param str $sql
@return array hitokotoData
*/
function get_array($link,$sql){
    $data = array();
    //var_dump($sql);
    if($result = mysqli_query($link,$sql)){
        if(mysqli_num_rows($result) >0){
            while($row  = mysqli_fetch_assoc($result)){
                $data[] = $row;
            }
        }
        mysqli_free_result($result);
    }
    return $data;
}
function deleteSHOPtable($link,$idNum){
    $sql ='DELETE FROM shop_stock WHERE id= \''.$idNum.'\'';
    return insert_db($link,$sql);
}


/*
db切断
@param obj $link
*/
function close_db_connect($link){
    mysqli_close($link);
}


/*input_value_check($price,$quantity)
@param str $price,$quantity
@return bool TRUE or FALSE
*/
function input_check_value($name,$price,$quantity){
    if(!empty($name)||!empty($price)||!empty($quantity)){
       return true;
    }
}
function input_check_Value_box($key){
    if(mb_strlen($key)>0){
        return true;
    }
}
/*
function input_check_number_shop($price,$quantity){
    if(preg_match('/^[0-9]+$/',$price)|| preg_match('/^[0-9]+$/',$quantity)){
        return true;
    }
}
*/
function input_check_shop_price($price){
    if(preg_match('/^([1-9][0-9]*)$/',$price)){
        return true;
    }
}
function input_check_shop_quantity($quantity){
    if(preg_match('/^([1-9][0-9]*)$/',$quantity)){
        return true;
    }
}

function number_check($change_amount){
    if(preg_match('/^([1-9][0-9]*)$/',$change_amount)){
        return TRUE;
    }else{
        return FALSE;
    }
}
/*@param str $type
*/
function file_type_check($type){
    global $err_msg;
    if($type !=='image/jpeg' && $type !== 'image/png'){
        $err_msg[] = 'ファイル形式はjpegとpngを入れてください';
    }
}
/*ifle_upload
*/
function file_upload(){
    global $info_data;
    global $err_msg;
    if(move_uploaded_file($_FILES['file']['tmp_name'],'img/'.$_FILES['file']['name'])){
        chmod('img/'.$_FILES['file']['name'],0644);
        $info_data[] = $_FILES['file']['name'].'をアップロードしました';
    }else{
        $err_msg[] = 'ファイルをアップロードできません';
    }
}

function shopping_cart_id($link){
    $sql = 'SELECT COUNT(*) FROM shopping_cart';
    $result = mysqli_query($link,$sql);
    $row = mysqli_fetch_array($result);
    $id = $row[0];
    $id_cnt = $id +1;
    mysqli_free_result($result);
    return $id_cnt;
}

/*
function shopping_id_table($link){
    $sql = 'SELECT COUNT(*) FROM shop_stock';
    $result = mysqli_query($link,$sql);
    $row = mysqli_fetch_array($result);
    $id = $row[0];
    $id_cnt = $id +1;
    mysqli_free_result($result);
    return $id_cnt;

}
*/
/*
function count_id($link){
    $sql = 'SELECT COUNT(*) FROM sign_up_user';
    $result = mysqli_query($link,$sql);
    $row = mysqli_fetch_array($result);
    $id= $row[0];
    $id_cnt = $id +1;
    mysqli_free_result($result);
    return $id_cnt;
}
 */   
function amount_select($idNum,$user_id,$link){    
    $sql = 'SELECT amount FROM shopping_cart WHERE item_id= \''.$idNum.'\' AND user_id = \''.$user_id.'\'';
    if($result = mysqli_query($link,$sql)){
        $row = mysqli_fetch_assoc($result);
        $select_amount = $row['amount'];
        mysqli_free_result($result);
        return $select_amount;
    }
}
function user_name_search($link){
    $sql = 'SELECT user_name FROM sign_up_user';
    return get_array($link,$sql);
}

function sign_up_insert($link,$passwd,$user_name,$date){
   $signData =array(
       'user_name' => $user_name,
       'password' => $passwd,
       'created_date' => $date,
       'updated_date' => $date
   );
   $sql ='INSERT INTO sign_up_user(user_name,password,created_date,updated_date) VALUES(\''.implode('\',\'',$signData).'\')';
        return insert_db($link,$sql);
}

function shop_insert($link,$file,$name,$price,$now_date,$status,$quantity){
    $shopData = array(
        //'id' => $id_cnt,
        'img' => $file,
        'name' => mysqli_real_escape_string($link,$name),
        'price' => $price,
        'quantity' => $quantity,
        'create_date' => $now_date,
        'updated_date' => $now_date,
        'status' => $status
    );
    $sql = 'INSERT INTO shop_stock(img,name,price,quantity,create_date,updated_date,status) VALUES(\''.implode('\',\'',$shopData).'\')';
        return insert_db($link,$sql);
}
function change_one($link,$idNum){
    $sql ='UPDATE shop_stock SET status = 1 WHERE id=\''.$idNum.'\'';
    return insert_db($link,$sql);
}
function change_zero($link,$idNum){
    $sql = 'UPDATE shop_stock SET status = 0 WHERE id = \''.$idNum.'\'';
    return insert_db($link,$sql);
}


function quantity_check($stock_change){
    if(preg_match('/^([1-9][0-9]*)$/',$stock_change)){
         return true;
    }
}
function empty_check_pass($passwd){
    if(mb_strlen($passwd)!==0){
        return true;
    }

}
function empty_check_user($user_name){
    if(mb_strlen($user_name)!==0){
        return true;
    }
}

function Character_check_user_name($user_name){
    if(preg_match('/\A[a-z\d]{6,}+\z/i',$user_name)){
        return true;
   }
}
function Charcter_check_passwd($passwd){
    if(preg_match('/\A[a-z\d]{6,}+\z/i',$passwd)){
        return true;
    }
}



function shop_stock_change($link,$idNum,$stock_change){
    $sql = 'UPDATE shop_stock SET quantity = \''.$stock_change.'\' WHERE id = \''.$idNum.'\'';
    return insert_db($link,$sql);
}
