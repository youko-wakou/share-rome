<?php 
require_once '../shop/include/conf/const.php';
//model
require_once '../shop/include/model/function.php';
//////////////////////

////////////////////////////
session_start();
$login_err_flag = FALSE;
$user_name = '';
if(isset($_SESSION['user_id'])=== TRUE){
    //ログイン済みの場合の処理
    header('Location:shop_goods.php');
    exit;
}

//セッションIDからログインエラーフラグを確認
if(isset($_SESSION['login_err_flag'])=== TRUE){
    //ログインエラーフラグを取得
    $login_err_flag = $_SESSION['login_err_flag'];
    $_SESSION['login_err_flag'] = FALSE;
}else{
    //セッション変数がなければ
    $login_err_flag = FALSE;
}
/*
//COOKIEからメールアドレスを取得
if(isset($_COOKIE['pass']) ===TRUE){
    $passwd = $_COOKIE['pass'];
}else{
    $passwd = '';
}
*/
if(isset($_COOKIE['user'])=== TRUE){
    $user_name = $_COOKIE['user'];
}else{
    $user_name = '';
}
include_once '../shop/include/view/login_top.php';