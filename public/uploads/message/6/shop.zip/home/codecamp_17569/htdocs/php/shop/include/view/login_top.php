<!DOCTYPE html>
<html lang="ja">
    <head>
        <meta charset="utf-8">
        <title> ログインページ</title>
    </head>
    <body>
        <div id="wrap">
            <header>
                <h1>CodeCampSHOP</h1>
            </header>
            <div id="form-range">
                <form method="post" action = "login.php">
                    <div class="form-box">
                        <input type="text" name="user" id="user" placeholder="ユーザー名" value="<?php echo $user_name; ?>">
                    </div>
                    <div class="post">
                        <input type="password" name="pass" id="pass" placeholder="パスワード">
                    </div>
                    <div class="form-box">
                        <input type="submit" value="ログイン">
                    </div>
                    
                </form>
    <?php if($login_err_flag === TRUE){?>
                <p>ユーザーネームかパスワードが間違っています</p>
    <?php } ?>
            <a href="sign_up.php" >ユーザーの新規登録</a>
            </div>
      </div>
        
    </body>
</html>